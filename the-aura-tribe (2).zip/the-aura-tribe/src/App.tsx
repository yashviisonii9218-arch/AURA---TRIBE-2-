import React from 'react'
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'
import { Navigation } from '@/components/layout/Navigation'
import { Footer } from '@/components/layout/Footer'
import { AnimatedBackground } from '@/components/layout/AnimatedBackground'
import { ParticleField } from '@/components/ui/ParticleField'
import { PageTransition } from '@/components/layout/PageTransition'
import { HomePage } from '@/pages/HomePage'
import { AboutPage } from '@/pages/AboutPage'
import { WellnessPage } from '@/pages/WellnessPage'
import { StorePage } from '@/pages/StorePage'
import { ContactPage } from '@/pages/ContactPage'

function ScrollToTop() {
  const { pathname } = useLocation()
  React.useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])
  return null
}

function AnimatedRoutes() {
  const location = useLocation()
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<PageTransition><HomePage /></PageTransition>} />
        <Route path="/about" element={<PageTransition><AboutPage /></PageTransition>} />
        <Route path="/wellness" element={<PageTransition><WellnessPage /></PageTransition>} />
        <Route path="/store" element={<PageTransition><StorePage /></PageTransition>} />
        <Route path="/contact" element={<PageTransition><ContactPage /></PageTransition>} />
      </Routes>
    </AnimatePresence>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-aura-ivory text-aura-text font-sans selection:bg-aura-gold selection:text-white">
        <AnimatedBackground />
        <ParticleField count={25} color="#C5A059" />
        <Navigation />
        <ScrollToTop />
        <main>
          <AnimatedRoutes />
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  )
}
