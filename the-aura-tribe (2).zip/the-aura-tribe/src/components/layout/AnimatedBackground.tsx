import React from 'react'
import { GradientOrb } from '@/components/ui/GradientOrb'

export function AnimatedBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      <GradientOrb
        className="top-[-10%] left-[-10%]"
        color="#E8E6E1"
        size={500}
        blur={150}
        duration={10}
      />
      <GradientOrb
        className="bottom-[-10%] right-[-10%]"
        color="#D4CFC7"
        size={600}
        blur={180}
        duration={12}
      />
      <GradientOrb
        className="top-[40%] left-[60%]"
        color="#8A9A87"
        size={300}
        blur={100}
        duration={8}
      />
      <GradientOrb
        className="top-[20%] right-[30%]"
        color="#C5A059"
        size={200}
        blur={80}
        duration={6}
      />
    </div>
  )
}
