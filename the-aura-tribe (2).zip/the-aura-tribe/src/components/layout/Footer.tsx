import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Sparkles, Instagram, Twitter, Facebook, Youtube, ArrowUpRight } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'

const footerLinks = {
  explore: [
    { name: 'About Us', path: '/about' },
    { name: 'Wellness Programs', path: '/wellness' },
    { name: 'The Store', path: '/store' },
    { name: 'Journal', path: '#' },
    { name: 'Events', path: '#' },
  ],
  wellness: [
    { name: 'Physical Wellness', path: '/wellness' },
    { name: 'Mental Wellness', path: '/wellness' },
    { name: 'Spiritual Wellness', path: '/wellness' },
    { name: 'Retreats', path: '#' },
    { name: 'Workshops', path: '#' },
  ],
  support: [
    { name: 'Contact Us', path: '/contact' },
    { name: 'FAQ', path: '#' },
    { name: 'Shipping', path: '#' },
    { name: 'Returns', path: '#' },
    { name: 'Privacy Policy', path: '#' },
  ],
}

const socialLinks = [
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Youtube, href: '#', label: 'YouTube' },
]

export function Footer() {
  return (
    <footer className="bg-aura-text text-aura-ivory relative overflow-hidden">
      {/* Decorative gradient */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-aura-gold/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 pt-20 pb-8 relative">
        {/* Top Section */}
        <div className="grid lg:grid-cols-12 gap-12 mb-16">
          {/* Brand Column */}
          <div className="lg:col-span-4">
            <ScrollReveal>
              <Link to="/" className="flex items-center gap-2.5 mb-6">
                <div className="w-10 h-10 bg-aura-gold rounded-full flex items-center justify-center">
                  <Sparkles size={20} className="text-white" />
                </div>
                <span className="text-2xl font-serif tracking-tight">The Aura Tribe</span>
              </Link>
              <p className="text-aura-text-muted leading-relaxed mb-8 max-w-sm">
                Elevating human consciousness through holistic wellness, mindful living, and community connection. Your journey to inner peace begins here.
              </p>
              <div className="flex gap-3">
                {socialLinks.map((social) => (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-11 h-11 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-aura-text-muted hover:text-aura-gold hover:border-aura-gold/30 transition-colors"
                    aria-label={social.label}
                  >
                    <social.icon size={18} />
                  </motion.a>
                ))}
              </div>
            </ScrollReveal>
          </div>

          {/* Links Columns */}
          <div className="lg:col-span-8 grid sm:grid-cols-3 gap-8">
            <ScrollReveal delay={0.1}>
              <h4 className="text-sm font-semibold uppercase tracking-wider text-aura-gold mb-6">Explore</h4>
              <ul className="space-y-3">
                {footerLinks.explore.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.path}
                      className="text-aura-text-muted hover:text-aura-ivory transition-colors inline-flex items-center gap-1 group"
                    >
                      {link.name}
                      <ArrowUpRight size={12} className="opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                    </Link>
                  </li>
                ))}
              </ul>
            </ScrollReveal>

            <ScrollReveal delay={0.2}>
              <h4 className="text-sm font-semibold uppercase tracking-wider text-aura-gold mb-6">Wellness</h4>
              <ul className="space-y-3">
                {footerLinks.wellness.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.path}
                      className="text-aura-text-muted hover:text-aura-ivory transition-colors inline-flex items-center gap-1 group"
                    >
                      {link.name}
                      <ArrowUpRight size={12} className="opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                    </Link>
                  </li>
                ))}
              </ul>
            </ScrollReveal>

            <ScrollReveal delay={0.3}>
              <h4 className="text-sm font-semibold uppercase tracking-wider text-aura-gold mb-6">Support</h4>
              <ul className="space-y-3">
                {footerLinks.support.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.path}
                      className="text-aura-text-muted hover:text-aura-ivory transition-colors inline-flex items-center gap-1 group"
                    >
                      {link.name}
                      <ArrowUpRight size={12} className="opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                    </Link>
                  </li>
                ))}
              </ul>
            </ScrollReveal>
          </div>
        </div>

        {/* Newsletter */}
        <ScrollReveal>
          <div className="border-t border-white/10 pt-12 mb-12">
            <div className="max-w-xl">
              <h4 className="text-xl font-serif mb-3">Join the Inner Circle</h4>
              <p className="text-aura-text-muted mb-6">Receive weekly wisdom, exclusive offers, and early access to new collections.</p>
              <form className="flex gap-3" onSubmit={(e) => e.preventDefault()}>
                <input
                  type="email"
                  placeholder="your@email.com"
                  className="flex-1 px-5 py-3 rounded-full bg-white/5 border border-white/10 text-aura-ivory placeholder:text-aura-text-muted focus:outline-none focus:border-aura-gold/50 transition-colors"
                />
                <button
                  type="submit"
                  className="px-6 py-3 rounded-full bg-aura-gold text-white font-medium hover:bg-aura-earth transition-colors"
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </ScrollReveal>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-aura-text-muted">
          <p>&copy; 2026 The Aura Tribe. All rights reserved.</p>
          <div className="flex gap-8">
            <Link to="#" className="hover:text-aura-ivory transition-colors">Privacy Policy</Link>
            <Link to="#" className="hover:text-aura-ivory transition-colors">Terms of Service</Link>
            <Link to="#" className="hover:text-aura-ivory transition-colors">Cookie Settings</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
