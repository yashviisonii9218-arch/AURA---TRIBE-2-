import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Sparkles, ArrowRight } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'
import { Button } from '@/components/ui/Button'
import { MagneticButton } from '@/components/ui/MagneticButton'

export function CTASection() {
  return (
    <section className="py-24 lg:py-32 px-6 relative overflow-hidden">
      <div className="max-w-4xl mx-auto text-center relative">
        <ScrollReveal>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-aura-gold/10 rounded-full pointer-events-none"
          />
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 40, repeat: Infinity, ease: 'linear' }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] border border-aura-sage/10 rounded-full pointer-events-none"
          />

          <div className="relative z-10">
            <div className="w-16 h-16 mx-auto mb-8 rounded-full bg-aura-gold/10 flex items-center justify-center">
              <Sparkles size={28} className="text-aura-gold" />
            </div>

            <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-aura-text mb-6 leading-tight">
              Ready to Begin Your{' '}
              <span className="text-aura-gold italic">Journey?</span>
            </h2>

            <p className="text-aura-text-light text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
              Join thousands of seekers who have found their balance. Start your wellness journey today with a complimentary consultation.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <MagneticButton>
                <Link to="/contact">
                  <Button variant="primary" size="lg" showArrow>
                    Book a Free Consultation
                  </Button>
                </Link>
              </MagneticButton>
              <MagneticButton>
                <Link to="/wellness">
                  <Button variant="outline" size="lg">
                    Explore Programs
                  </Button>
                </Link>
              </MagneticButton>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}
