import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Heart, Sun, Moon, ChevronRight, Sparkles } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'
import { FloatingCard } from '@/components/ui/FloatingCard'

const categories = [
  {
    title: 'Physical',
    subtitle: 'Movement & Vitality',
    description: 'Restore your body's natural vitality through mindful movement, yoga, and strength practices designed for lasting wellness.',
    icon: Heart,
    color: 'bg-aura-sage',
    textColor: 'text-aura-sage-dark',
    lightColor: 'bg-aura-sage/10',
    path: '/wellness',
  },
  {
    title: 'Mental',
    subtitle: 'Clarity & Focus',
    description: 'Cultivate mental resilience and clarity through meditation, mindfulness, and cognitive wellness practices.',
    icon: Sun,
    color: 'bg-aura-earth',
    textColor: 'text-aura-earth',
    lightColor: 'bg-aura-earth/10',
    path: '/wellness',
  },
  {
    title: 'Spiritual',
    subtitle: 'Inner Peace',
    description: 'Connect with your deeper purpose through energy work, sound healing, and spiritual practices that nourish the soul.',
    icon: Moon,
    color: 'bg-aura-gold',
    textColor: 'text-aura-gold-dark',
    lightColor: 'bg-aura-gold/10',
    path: '/wellness',
  },
]

export function FeaturedCategories() {
  return (
    <section className="py-24 lg:py-32 px-6 relative">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <ScrollReveal className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-aura-gold/10 rounded-full text-aura-gold text-sm font-medium mb-6"
          >
            <Sparkles size={14} />
            <span>Our Philosophy</span>
          </motion.div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-aura-text mb-6 leading-tight">
            Our Pillars of Wellness
          </h2>
          <p className="text-aura-text-light text-lg max-w-2xl mx-auto leading-relaxed">
            A holistic approach to nurturing every aspect of your being. We believe true wellness emerges when body, mind, and spirit are in harmony.
          </p>
        </ScrollReveal>

        {/* Cards Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {categories.map((cat, idx) => (
            <ScrollReveal key={cat.title} delay={idx * 0.15}>
              <Link to={cat.path}>
                <motion.div
                  whileHover={{ y: -12 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  className="group bg-white rounded-[2rem] p-8 lg:p-10 shadow-sm border border-aura-border hover:shadow-xl hover:shadow-aura-text/5 transition-all duration-500 h-full"
                >
                  {/* Icon */}
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: 'spring', stiffness: 400 }}
                    className={`w-16 h-16 ${cat.color} rounded-2xl flex items-center justify-center text-white mb-8 shadow-lg`}
                  >
                    <cat.icon size={28} />
                  </motion.div>

                  {/* Content */}
                  <div className={`inline-block px-3 py-1 ${cat.lightColor} rounded-full text-xs font-semibold uppercase tracking-wider mb-4 ${cat.textColor}`}>
                    {cat.subtitle}
                  </div>
                  <h3 className="text-2xl lg:text-3xl font-serif text-aura-text mb-4 group-hover:text-aura-gold transition-colors">
                    {cat.title} Wellness
                  </h3>
                  <p className="text-aura-text-light leading-relaxed mb-8">
                    {cat.description}
                  </p>

                  {/* CTA */}
                  <div className="flex items-center text-aura-gold font-medium text-sm group-hover:gap-3 transition-all">
                    <span>Explore Programs</span>
                    <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
                  </div>

                  {/* Decorative element */}
                  <div className={`mt-8 h-1 w-12 ${cat.color} rounded-full opacity-30 group-hover:w-20 transition-all duration-500`} />
                </motion.div>
              </Link>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
