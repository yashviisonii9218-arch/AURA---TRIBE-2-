import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Leaf, ArrowRight, Star, Play } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { MagneticButton } from '@/components/ui/MagneticButton'

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -60 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.2, ease: [0.25, 0.1, 0.25, 1] }}
            className="order-2 lg:order-1"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-aura-sage/10 rounded-full text-aura-sage-dark text-sm font-medium mb-8 border border-aura-sage/20"
            >
              <Leaf size={16} className="animate-pulse" />
              <span>Holistic Wellness Reimagined</span>
            </motion.div>

            {/* Headline */}
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-serif text-aura-text leading-[1.05] mb-8">
              Find your balance.{' '}
              <span className="text-aura-gold italic">Discover your aura.</span>
            </h1>

            {/* Description */}
            <p className="text-lg text-aura-text-light leading-relaxed mb-10 max-w-lg">
              A sanctuary for mind, body, and spirit. Curated experiences and premium essentials for the modern seeker of peace and inner harmony.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap gap-4 mb-12">
              <MagneticButton>
                <Link to="/wellness">
                  <Button variant="primary" size="lg" showArrow>
                    Explore Wellness
                  </Button>
                </Link>
              </MagneticButton>
              <MagneticButton>
                <Link to="/store">
                  <Button variant="outline" size="lg">
                    View Collection
                  </Button>
                </Link>
              </MagneticButton>
            </div>

            {/* Stats */}
            <div className="flex gap-8">
              {[
                { value: '15K+', label: 'Members' },
                { value: '98%', label: 'Satisfaction' },
                { value: '50+', label: 'Expert Guides' },
              ].map((stat, idx) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + idx * 0.1, duration: 0.5 }}
                >
                  <div className="text-2xl font-serif text-aura-gold">{stat.value}</div>
                  <div className="text-sm text-aura-text-light">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
            className="order-1 lg:order-2 relative"
          >
            <div className="relative aspect-[4/5] rounded-[2.5rem] overflow-hidden shadow-2xl shadow-aura-text/10">
              {/* Placeholder for hero image - in production, replace with actual image */}
              <div className="absolute inset-0 bg-gradient-to-br from-aura-beige via-aura-border to-aura-sage/20 flex items-center justify-center">
                <div className="text-center p-12">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                    className="w-24 h-24 mx-auto mb-6 rounded-full border-2 border-dashed border-aura-gold/30 flex items-center justify-center"
                  >
                    <div className="w-16 h-16 rounded-full bg-aura-gold/10 flex items-center justify-center">
                      <Play size={24} className="text-aura-gold ml-1" />
                    </div>
                  </motion.div>
                  <p className="font-serif text-aura-text text-xl">Wellness Lifestyle</p>
                  <p className="text-aura-text-light text-sm mt-2">Your journey begins here</p>
                </div>
              </div>
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-aura-text/10 via-transparent to-transparent" />
            </div>

            {/* Floating Review Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1, duration: 0.6 }}
              className="absolute -bottom-6 -left-6 lg:-left-12 bg-white p-6 rounded-2xl shadow-xl max-w-[220px] border border-aura-border/50"
            >
              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              >
                <div className="flex items-center gap-1 mb-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} size={14} className="text-aura-gold fill-aura-gold" />
                  ))}
                  <span className="text-xs font-bold text-aura-text ml-1">4.9/5</span>
                </div>
                <p className="text-xs text-aura-text-light leading-relaxed">
                  "The Aura Tribe transformed my daily routine. I've never felt more centered and alive."
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-aura-sage/20 flex items-center justify-center">
                    <span className="text-xs font-medium text-aura-sage-dark">SK</span>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-aura-text">Sarah K.</p>
                    <p className="text-[10px] text-aura-text-muted">Wellness Member</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>

            {/* Floating Stats Card */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1.2, duration: 0.6 }}
              className="absolute -top-4 -right-4 lg:-right-8 bg-white/80 backdrop-blur-md p-4 rounded-2xl shadow-lg border border-aura-border/30"
            >
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-aura-gold/10 flex items-center justify-center">
                    <ArrowRight size={18} className="text-aura-gold -rotate-45" />
                  </div>
                  <div>
                    <p className="text-lg font-serif text-aura-text">2,400+</p>
                    <p className="text-xs text-aura-text-light">Sessions This Month</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
