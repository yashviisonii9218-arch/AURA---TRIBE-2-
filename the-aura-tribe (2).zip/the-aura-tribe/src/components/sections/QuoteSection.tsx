import React from 'react'
import { motion } from 'framer-motion'
import { Quote } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'

export function QuoteSection() {
  return (
    <section className="py-24 lg:py-32 px-6 bg-aura-beige relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-aura-gold/5 rounded-full blur-[100px]" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-aura-sage/5 rounded-full blur-[120px]" />

      <div className="max-w-4xl mx-auto text-center relative">
        <ScrollReveal>
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="w-16 h-16 mx-auto mb-10 rounded-full bg-aura-gold/10 flex items-center justify-center"
          >
            <Quote size={28} className="text-aura-gold" />
          </motion.div>

          <blockquote className="text-3xl md:text-4xl lg:text-5xl font-serif text-aura-text leading-tight mb-8">
            "Wellness is the complete integration of{' '}
            <span className="text-aura-gold italic">body, mind, and spirit</span>
            — the realization that everything we do, think, feel, and believe has an effect on our state of well-being."
          </blockquote>

          <div className="flex items-center justify-center gap-4">
            <div className="w-12 h-px bg-aura-gold/30" />
            <p className="text-aura-text-light text-lg font-medium">The Aura Tribe Philosophy</p>
            <div className="w-12 h-px bg-aura-gold/30" />
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}
