import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ShoppingBag, Star, Heart, ArrowRight } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'
import { Button } from '@/components/ui/Button'
import { formatPrice } from '@/lib/utils'

const products = [
  {
    id: 1,
    name: 'Aura Essential Oil Set',
    price: 48.00,
    originalPrice: 65.00,
    tag: 'Bestseller',
    rating: 4.9,
    reviews: 234,
    color: 'bg-aura-beige',
    accentColor: 'bg-aura-sage/20',
  },
  {
    id: 2,
    name: 'Silk Meditation Cushion',
    price: 85.00,
    tag: 'New',
    rating: 5.0,
    reviews: 89,
    color: 'bg-aura-border',
    accentColor: 'bg-aura-earth/20',
  },
  {
    id: 3,
    name: 'Sage & Palo Santo Bundle',
    price: 24.00,
    tag: 'Popular',
    rating: 4.8,
    reviews: 456,
    color: 'bg-aura-beige',
    accentColor: 'bg-aura-gold/20',
  },
  {
    id: 4,
    name: 'Organic Matcha Ritual',
    price: 36.00,
    rating: 4.7,
    reviews: 178,
    color: 'bg-aura-border',
    accentColor: 'bg-aura-sage/20',
  },
]

export function StorePreview() {
  return (
    <section className="py-24 lg:py-32 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16">
          <ScrollReveal>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-aura-gold/10 rounded-full text-aura-gold text-sm font-medium mb-6">
              <ShoppingBag size={14} />
              <span>The Collection</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-serif text-aura-text mb-4">
              The Wellness Store
            </h2>
            <p className="text-aura-text-light text-lg max-w-xl leading-relaxed">
              Curated essentials for your daily rituals. Sustainably sourced, ethically made, and designed to elevate your space.
            </p>
          </ScrollReveal>
          <ScrollReveal delay={0.2} className="mt-6 md:mt-0">
            <Link to="/store">
              <Button variant="outline" showArrow>
                View All Products
              </Button>
            </Link>
          </ScrollReveal>
        </div>

        {/* Product Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, idx) => (
            <ScrollReveal key={product.id} delay={idx * 0.1}>
              <motion.div
                whileHover={{ y: -8 }}
                transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                className="group bg-white rounded-2xl overflow-hidden border border-aura-border shadow-sm hover:shadow-xl hover:shadow-aura-text/5 transition-all duration-500"
              >
                {/* Image Area */}
                <div className={`relative aspect-square ${product.color} flex items-center justify-center overflow-hidden`}>
                  <div className={`w-24 h-24 rounded-full ${product.accentColor} flex items-center justify-center`}>
                    <ShoppingBag size={40} className="text-aura-text/20" />
                  </div>

                  {/* Tag */}
                  {product.tag && (
                    <span className="absolute top-4 left-4 bg-aura-text text-white text-xs font-bold px-3 py-1.5 rounded-full">
                      {product.tag}
                    </span>
                  )}

                  {/* Wishlist */}
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center text-aura-text-light hover:text-red-500 hover:bg-white transition-colors shadow-sm"
                  >
                    <Heart size={16} />
                  </motion.button>

                  {/* Quick Add Overlay */}
                  <motion.div
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                    className="absolute inset-0 bg-aura-text/5 flex items-center justify-center"
                  >
                    <motion.button
                      initial={{ y: 20, opacity: 0 }}
                      whileHover={{ y: 0, opacity: 1 }}
                      className="px-6 py-3 bg-aura-gold text-white text-sm font-medium rounded-full shadow-lg hover:bg-aura-earth transition-colors"
                    >
                      Quick Add
                    </motion.button>
                  </motion.div>
                </div>

                {/* Product Info */}
                <div className="p-5">
                  <div className="flex items-center gap-1 mb-2">
                    <Star size={12} className="text-aura-gold fill-aura-gold" />
                    <span className="text-xs font-medium text-aura-text">{product.rating}</span>
                    <span className="text-xs text-aura-text-muted">({product.reviews})</span>
                  </div>
                  <h3 className="text-base font-medium text-aura-text mb-2 group-hover:text-aura-gold transition-colors">
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-serif text-aura-gold">{formatPrice(product.price)}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-aura-text-muted line-through">
                        {formatPrice(product.originalPrice)}
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
