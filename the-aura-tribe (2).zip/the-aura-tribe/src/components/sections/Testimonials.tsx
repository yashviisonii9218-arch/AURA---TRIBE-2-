import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'

const testimonials = [
  {
    id: 1,
    name: 'Emily Richardson',
    role: 'Yoga Instructor',
    avatar: 'ER',
    rating: 5,
    text: 'The Aura Tribe has completely transformed my approach to wellness. Their essential oils and meditation guides have become an integral part of my daily practice. The quality is unmatched.',
  },
  {
    id: 2,
    name: 'Marcus Chen',
    role: 'Creative Director',
    avatar: 'MC',
    rating: 5,
    text: 'As someone who deals with high stress, finding The Aura Tribe was a game-changer. Their mental wellness programs helped me find clarity and focus I didn't know was possible.',
  },
  {
    id: 3,
    name: 'Sofia Martinez',
    role: 'Entrepreneur',
    avatar: 'SM',
    rating: 5,
    text: 'The spiritual wellness retreats are nothing short of magical. Every detail is thoughtfully curated, from the location to the guided sessions. I leave feeling renewed every single time.',
  },
  {
    id: 4,
    name: 'James Wright',
    role: 'Physician',
    avatar: 'JW',
    rating: 5,
    text: 'I recommend The Aura Tribe to my patients looking for holistic wellness solutions. Their evidence-based approach combined with ancient wisdom creates truly transformative results.',
  },
]

export function Testimonials() {
  const [current, setCurrent] = useState(0)

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length)
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length)

  return (
    <section className="py-24 lg:py-32 px-6 bg-aura-beige relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-aura-gold/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-5xl mx-auto relative">
        <ScrollReveal className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif text-aura-text mb-4">
            What Our Community Says
          </h2>
          <p className="text-aura-text-light text-lg max-w-xl mx-auto">
            Real stories from real people who have discovered their aura.
          </p>
        </ScrollReveal>

        <ScrollReveal>
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
                className="bg-white rounded-[2.5rem] p-8 md:p-12 lg:p-16 shadow-lg border border-aura-border/50 text-center"
              >
                <div className="w-14 h-14 mx-auto mb-8 rounded-full bg-aura-gold/10 flex items-center justify-center">
                  <Quote size={24} className="text-aura-gold" />
                </div>

                <div className="flex justify-center gap-1 mb-6">
                  {[...Array(testimonials[current].rating)].map((_, i) => (
                    <Star key={i} size={18} className="text-aura-gold fill-aura-gold" />
                  ))}
                </div>

                <blockquote className="text-xl md:text-2xl text-aura-text leading-relaxed mb-8 max-w-3xl mx-auto font-serif">
                  "{testimonials[current].text}"
                </blockquote>

                <div className="flex items-center justify-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-aura-sage/20 flex items-center justify-center">
                    <span className="text-sm font-medium text-aura-sage-dark">
                      {testimonials[current].avatar}
                    </span>
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-aura-text">{testimonials[current].name}</p>
                    <p className="text-sm text-aura-text-light">{testimonials[current].role}</p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={prev}
                className="w-12 h-12 rounded-full border border-aura-border bg-white flex items-center justify-center text-aura-text hover:bg-aura-gold hover:text-white hover:border-aura-gold transition-colors"
              >
                <ChevronLeft size={20} />
              </motion.button>

              <div className="flex gap-2">
                {testimonials.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrent(idx)}
                    className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                      idx === current ? 'bg-aura-gold w-8' : 'bg-aura-border hover:bg-aura-gold/50'
                    }`}
                  />
                ))}
              </div>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={next}
                className="w-12 h-12 rounded-full border border-aura-border bg-white flex items-center justify-center text-aura-text hover:bg-aura-gold hover:text-white hover:border-aura-gold transition-colors"
              >
                <ChevronRight size={20} />
              </motion.button>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}
