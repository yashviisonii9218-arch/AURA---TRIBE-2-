import React from 'react'
import { cn } from '@/lib/utils'
import { ArrowRight } from 'lucide-react'
import { motion } from 'framer-motion'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'gold' | 'ghost' | 'text'
  size?: 'sm' | 'md' | 'lg'
  showArrow?: boolean
  children: React.ReactNode
  href?: string
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', showArrow = false, children, href, ...props }, ref) => {
    const baseStyles = cn(
      'relative inline-flex items-center justify-center gap-2 font-medium tracking-wide transition-all duration-300 rounded-full',
      'focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-aura-gold/50',
      'disabled:opacity-50 disabled:cursor-not-allowed'
    )

    const variants = {
      primary: 'bg-aura-text text-aura-ivory hover:bg-aura-gold hover:shadow-lg hover:shadow-aura-gold/20 btn-shine',
      outline: 'border-2 border-aura-text text-aura-text hover:bg-aura-text hover:text-aura-ivory',
      gold: 'bg-aura-gold text-white hover:bg-aura-earth hover:shadow-lg hover:shadow-aura-gold/20 btn-shine',
      ghost: 'text-aura-text hover:bg-aura-beige',
      text: 'text-aura-gold hover:text-aura-earth underline-offset-4 hover:underline',
    }

    const sizes = {
      sm: 'px-5 py-2 text-sm',
      md: 'px-8 py-3.5 text-sm',
      lg: 'px-10 py-4 text-base',
    }

    const classes = cn(baseStyles, variants[variant], sizes[size], className)

    const content = (
      <>
        <span className="relative z-10">{children}</span>
        {showArrow && (
          <motion.span
            className="relative z-10"
            initial={{ x: 0 }}
            whileHover={{ x: 4 }}
          >
            <ArrowRight size={16} />
          </motion.span>
        )}
      </>
    )

    if (href) {
      return (
        <a href={href} className={classes}>
          {content}
        </a>
      )
    }

    return (
      <button ref={ref} className={classes} {...props}>
        {content}
      </button>
    )
  }
)

Button.displayName = 'Button'
