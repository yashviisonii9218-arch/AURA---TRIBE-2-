import React from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

interface FloatingCardProps {
  children: React.ReactNode
  className?: string
  delay?: number
  floatIntensity?: number
}

export function FloatingCard({
  children,
  className,
  delay = 0,
  floatIntensity = 10,
}: FloatingCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay, ease: 'easeOut' }}
      whileHover={{ y: -8, transition: { duration: 0.3 } }}
      className={cn(
        'bg-white rounded-3xl p-8 shadow-sm border border-aura-border',
        'hover:shadow-xl hover:shadow-aura-text/5 transition-shadow duration-500',
        className
      )}
    >
      {children}
    </motion.div>
  )
}
