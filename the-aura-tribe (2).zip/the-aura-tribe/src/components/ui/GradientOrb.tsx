import React from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

interface GradientOrbProps {
  className?: string
  color?: string
  size?: number
  blur?: number
  duration?: number
}

export function GradientOrb({
  className,
  color = '#E8E6E1',
  size = 400,
  blur = 120,
  duration = 8,
}: GradientOrbProps) {
  return (
    <motion.div
      className={cn('absolute rounded-full pointer-events-none', className)}
      style={{
        width: size,
        height: size,
        backgroundColor: color,
        filter: `blur(${blur}px)`,
      }}
      animate={{
        scale: [1, 1.2, 1],
        opacity: [0.4, 0.6, 0.4],
        x: [0, 30, 0],
        y: [0, -20, 0],
      }}
      transition={{
        duration,
        repeat: Infinity,
        ease: 'easeInOut',
      }}
    />
  )
}
