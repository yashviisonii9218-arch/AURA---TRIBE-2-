import React from 'react'
import { motion } from 'framer-motion'
import { Leaf, Users, Award, Heart, Sparkles } from 'lucide-react'
import { ScrollReveal } from '@/components/sections/ScrollReveal'
import { Button } from '@/components/ui/Button'

const timeline = [
  { year: '2018', title: 'The Seed', desc: 'Founded with a vision to bridge ancient wisdom and modern science. Our first meditation circle gathered just 12 people in a small studio.' },
  { year: '2020', title: 'Growth', desc: 'Expanded our community to over 50,000 active members globally. Launched our first digital wellness platform during a time when connection was needed most.' },
  { year: '2023', title: 'The Store', desc: 'Launched our curated collection of sustainable wellness essentials. Every product is hand-selected for quality, ethics, and environmental impact.' },
  { year: '2026', title: 'Global Aura', desc: 'Recognized as a leading voice in the luxury wellness movement. Operating retreats across 12 countries with a team of 200+ wellness experts.' },
]

const values = [
  { icon: Heart, title: 'Authenticity', desc: 'We believe in genuine connection and real results. No shortcuts, no gimmicks.' },
  { icon: Leaf, title: 'Sustainability', desc: 'Every product and practice is chosen with the planet in mind. We are stewards of the earth.' },
  { icon: Users, title: 'Community', desc: 'Wellness is better together. We foster inclusive spaces where everyone belongs.' },
  { icon: Award, title: 'Excellence', desc: 'We hold ourselves to the highest standards in everything we create and offer.' },
]

export function AboutPage() {
  return (
    <div className="pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-32">
          <ScrollReveal>
            <div className="relative">
              <div className="aspect-[4/5] rounded-[2.5rem] bg-gradient-to-br from-aura-beige to-aura-border overflow-hidden relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                      className="w-32 h-32 mx-auto mb-6 rounded-full border-2 border-dashed border-aura-gold/20 flex items-center justify-center"
                    >
                      <div className="w-20 h-20 rounded-full bg-aura-gold/10 flex items-center justify-center">
                        <Leaf size={40} className="text-aura-gold" />
                      </div>
                    </motion.div>
                    <p className="font-serif text-aura-text text-2xl">Our Story</p>
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-8 -right-8 w-64 h-64 bg-aura-gold/10 rounded-full blur-[100px] pointer-events-none" />
            </div>
          </ScrollReveal>

          <ScrollReveal delay={0.2}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-aura-gold/10 rounded-full text-aura-gold text-sm font-medium mb-6">
              <Sparkles size={14} />
              <span>About Us</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif text-aura-text mb-6 leading-tight">
              Our Story
            </h1>
            <p className="text-aura-text-light text-lg leading-relaxed mb-6">
              Born from a desire to create a sanctuary in the chaos of modern life, The Aura Tribe is more than a brand — it is a movement. We believe that true wellness is the harmonious alignment of the physical, mental, and spiritual.
            </p>
            <p className="text-aura-text-light text-lg leading-relaxed mb-8">
              Our mission is to guide you back to yourself. Through curated experiences, sustainable products, and a supportive community, we provide the tools you need to discover your inner light.
            </p>
            <div className="flex gap-8">
              <div>
                <h4 className="text-3xl font-serif text-aura-gold mb-1">15K+</h4>
                <p className="text-sm text-aura-text-light">Community Members</p>
              </div>
              <div>
                <h4 className="text-3xl font-serif text-aura-gold mb-1">200+</h4>
                <p className="text-sm text-aura-text-light">Expert Guides</p>
              </div>
              <div>
                <h4 className="text-3xl font-serif text-aura-gold mb-1">12</h4>
                <p className="text-sm text-aura-text-light">Countries</p>
              </div>
            </div>
          </ScrollReveal>
        </div>

        {/* Values */}
        <ScrollReveal className="mb-8">
          <h2 className="text-3xl md:text-4xl font-serif text-aura-text text-center mb-4">Our Core Values</h2>
          <p className="text-aura-text-light text-center max-w-xl mx-auto mb-16">The principles that guide every decision we make and every experience we create.</p>
        </ScrollReveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-32">
          {values.map((value, idx) => (
            <ScrollReveal key={value.title} delay={idx * 0.1}>
              <motion.div
                whileHover={{ y: -8 }}
                className="bg-white rounded-2xl p-8 border border-aura-border hover:shadow-lg hover:shadow-aura-text/5 transition-all duration-300 h-full"
              >
                <div className="w-12 h-12 bg-aura-gold/10 rounded-xl flex items-center justify-center text-aura-gold mb-6">
                  <value.icon size={24} />
                </div>
                <h3 className="text-xl font-serif text-aura-text mb-3">{value.title}</h3>
                <p className="text-aura-text-light text-sm leading-relaxed">{value.desc}</p>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>

        {/* Timeline */}
        <ScrollReveal className="mb-12">
          <h2 className="text-3xl md:text-4xl font-serif text-aura-text text-center mb-4">Our Journey</h2>
          <p className="text-aura-text-light text-center max-w-xl mx-auto mb-16">From a small studio to a global wellness movement.</p>
        </ScrollReveal>

        <div className="relative max-w-4xl mx-auto">
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-aura-border md:-translate-x-1/2" />
          <div className="space-y-16">
            {timeline.map((item, idx) => (
              <ScrollReveal key={idx} delay={idx * 0.1}>
                <div className={`relative flex items-start md:items-center ${idx % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                  <div className="hidden md:block w-1/2 px-12">
                    {idx % 2 === 0 && (
                      <div className="text-right">
                        <h4 className="text-2xl font-serif text-aura-text mb-2">{item.title}</h4>
                        <p className="text-aura-text-light leading-relaxed">{item.desc}</p>
                      </div>
                    )}
                  </div>
                  <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-aura-gold rounded-full border-4 border-aura-ivory md:-translate-x-1/2 z-10 shadow-sm" />
                  <div className="pl-12 md:pl-0 md:w-1/2 md:px-12">
                    <span className="text-aura-gold font-serif text-3xl block mb-2">{item.year}</span>
                    <h4 className="text-xl font-bold text-aura-text md:hidden mb-2">{item.title}</h4>
                    <p className="text-aura-text-light md:hidden">{item.desc}</p>
                    {idx % 2 !== 0 && (
                      <div className="hidden md:block">
                        <h4 className="text-2xl font-serif text-aura-text mb-2">{item.title}</h4>
                        <p className="text-aura-text-light leading-relaxed">{item.desc}</p>
                      </div>
                    )}
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
