import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, MapPin, Phone, Send, CheckCircle, Sparkles, Instagram, Twitter, Facebook } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'
import { Button } from '@/components/ui/Button'

export function ContactPage() {
  const [submitted, setSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    interest: 'General Inquiry',
    message: '',
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  return (
    <div className="pt-32 pb-20 px-6 min-h-screen flex flex-col">
      <div className="max-w-7xl mx-auto w-full flex-grow">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left - Info */}
          <ScrollReveal>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-aura-gold/10 rounded-full text-aura-gold text-sm font-medium mb-6">
              <Sparkles size={14} />
              <span>Get in Touch</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif text-aura-text mb-6 leading-tight">
              Begin Your Journey
            </h1>
            <p className="text-aura-text-light text-lg leading-relaxed mb-12 max-w-lg">
              Ready to transform your life? Reach out to our team of wellness experts to find the perfect path for your unique journey.
            </p>

            <div className="space-y-8 mb-12">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-aura-sage/10 rounded-full flex items-center justify-center text-aura-sage flex-shrink-0">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="font-medium text-aura-text mb-1">Visit Us</h4>
                  <p className="text-aura-text-light">123 Serenity Lane, Malibu, CA 90265</p>
                  <p className="text-aura-text-light text-sm">Mon–Sat: 9am – 7pm</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-aura-sage/10 rounded-full flex items-center justify-center text-aura-sage flex-shrink-0">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="font-medium text-aura-text mb-1">Email Us</h4>
                  <p className="text-aura-text-light">hello@theauratribe.com</p>
                  <p className="text-aura-text-light text-sm">We respond within 24 hours</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-aura-sage/10 rounded-full flex items-center justify-center text-aura-sage flex-shrink-0">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="font-medium text-aura-text mb-1">Call Us</h4>
                  <p className="text-aura-text-light">+1 (555) 123-4567</p>
                  <p className="text-aura-text-light text-sm">Toll-free wellness hotline</p>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-aura-text mb-4">Follow Our Journey</h4>
              <div className="flex gap-3">
                {[Instagram, Twitter, Facebook].map((Icon, idx) => (
                  <motion.a
                    key={idx}
                    href="#"
                    whileHover={{ scale: 1.1, y: -2 }}
                    className="w-11 h-11 rounded-full bg-aura-beige flex items-center justify-center text-aura-text hover:bg-aura-gold hover:text-white transition-colors"
                  >
                    <Icon size={18} />
                  </motion.a>
                ))}
              </div>
            </div>
          </ScrollReveal>

          {/* Right - Form */}
          <ScrollReveal delay={0.2}>
            <div className="bg-white rounded-[2.5rem] p-8 md:p-10 lg:p-12 shadow-lg border border-aura-border relative overflow-hidden">
              {submitted && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="absolute inset-0 bg-white z-20 flex flex-col items-center justify-center"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', delay: 0.2 }}
                  >
                    <CheckCircle size={64} className="text-aura-gold mb-4" />
                  </motion.div>
                  <h3 className="text-2xl font-serif text-aura-text mb-2">Message Sent!</h3>
                  <p className="text-aura-text-light">We'll be in touch within 24 hours.</p>
                </motion.div>
              )}

              <h3 className="text-2xl font-serif text-aura-text mb-2">Send a Message</h3>
              <p className="text-aura-text-light text-sm mb-8">Fill out the form below and our team will reach out to you.</p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-aura-text mb-2">Name</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-aura-ivory border border-aura-border focus:border-aura-gold focus:ring-2 focus:ring-aura-gold/20 outline-none transition-all"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-aura-text mb-2">Email</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-aura-ivory border border-aura-border focus:border-aura-gold focus:ring-2 focus:ring-aura-gold/20 outline-none transition-all"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-aura-text mb-2">Interest</label>
                  <select
                    name="interest"
                    value={formData.interest}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl bg-aura-ivory border border-aura-border focus:border-aura-gold focus:ring-2 focus:ring-aura-gold/20 outline-none transition-all appearance-none"
                  >
                    <option>General Inquiry</option>
                    <option>Physical Wellness</option>
                    <option>Mental Wellness</option>
                    <option>Spiritual Wellness</option>
                    <option>Store Support</option>
                    <option>Partnerships</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-aura-text mb-2">Message</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl bg-aura-ivory border border-aura-border focus:border-aura-gold focus:ring-2 focus:ring-aura-gold/20 outline-none transition-all resize-none"
                    placeholder="How can we help you?"
                  />
                </div>

                <Button type="submit" variant="primary" className="w-full justify-center">
                  <Send size={16} />
                  Send Message
                </Button>
              </form>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </div>
  )
}
