import React from 'react'
import { HeroSection } from '@/components/sections/HeroSection'
import { FeaturedCategories } from '@/components/sections/FeaturedCategories'
import { QuoteSection } from '@/components/sections/QuoteSection'
import { StorePreview } from '@/components/sections/StorePreview'
import { Testimonials } from '@/components/sections/Testimonials'
import { CTASection } from '@/components/sections/CTASection'

export function HomePage() {
  return (
    <>
      <HeroSection />
      <FeaturedCategories />
      <QuoteSection />
      <StorePreview />
      <Testimonials />
      <CTASection />
    </>
  )
}
