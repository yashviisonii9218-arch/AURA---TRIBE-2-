import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ShoppingBag, Star, Heart, Filter } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'
import { Button } from '@/components/ui/Button'
import { formatPrice } from '@/lib/utils'

const categories = ['All', 'Essentials', 'Home', 'Body', 'Mind', 'Spirit']

const products = [
  { id: 1, name: 'Aura Essential Oil Set', price: 48.00, originalPrice: 65.00, category: 'Essentials', tag: 'Bestseller', rating: 4.9, reviews: 234, color: 'bg-aura-beige' },
  { id: 2, name: 'Silk Meditation Cushion', price: 85.00, category: 'Home', tag: 'New', rating: 5.0, reviews: 89, color: 'bg-aura-border' },
  { id: 3, name: 'Sage & Palo Santo Bundle', price: 24.00, category: 'Spirit', tag: 'Popular', rating: 4.8, reviews: 456, color: 'bg-aura-beige' },
  { id: 4, name: 'Organic Matcha Ritual', price: 36.00, category: 'Body', rating: 4.7, reviews: 178, color: 'bg-aura-border' },
  { id: 5, name: 'Crystal Healing Kit', price: 62.00, category: 'Spirit', tag: 'Limited', rating: 4.9, reviews: 312, color: 'bg-aura-beige' },
  { id: 6, name: 'Linen Yoga Mat', price: 120.00, category: 'Essentials', rating: 4.8, reviews: 245, color: 'bg-aura-border' },
  { id: 7, name: 'Mindfulness Journal', price: 28.00, category: 'Mind', tag: 'New', rating: 4.6, reviews: 156, color: 'bg-aura-beige' },
  { id: 8, name: 'Aromatherapy Diffuser', price: 95.00, category: 'Home', rating: 4.7, reviews: 198, color: 'bg-aura-border' },
  { id: 9, name: 'Herbal Tea Collection', price: 42.00, category: 'Body', rating: 4.8, reviews: 267, color: 'bg-aura-beige' },
]

export function StorePage() {
  const [activeCategory, setActiveCategory] = useState('All')
  const [wishlist, setWishlist] = useState<number[]>([])

  const filteredProducts = activeCategory === 'All'
    ? products
    : products.filter((p) => p.category === activeCategory)

  const toggleWishlist = (id: number) => {
    setWishlist((prev) =>
      prev.includes(id) ? prev.filter((w) => w !== id) : [...prev, id]
    )
  }

  return (
    <div className="pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <ScrollReveal className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-aura-gold/10 rounded-full text-aura-gold text-sm font-medium mb-6">
            <ShoppingBag size={14} />
            <span>The Collection</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif text-aura-text mb-6">
            The Wellness Store
          </h1>
          <p className="text-aura-text-light text-lg max-w-2xl mx-auto leading-relaxed">
            Curated essentials for your daily rituals. Sustainably sourced, ethically made, and designed to elevate your space.
          </p>
        </ScrollReveal>

        {/* Filters */}
        <ScrollReveal className="mb-12">
          <div className="flex flex-wrap items-center justify-center gap-3">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
                  activeCategory === cat
                    ? 'bg-aura-text text-white shadow-lg'
                    : 'bg-white text-aura-text border border-aura-border hover:border-aura-gold hover:text-aura-gold'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </ScrollReveal>

        {/* Product Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeCategory}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredProducts.map((product, idx) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05, duration: 0.4 }}
                layout
              >
                <motion.div
                  whileHover={{ y: -8 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  className="group bg-white rounded-2xl overflow-hidden border border-aura-border shadow-sm hover:shadow-xl hover:shadow-aura-text/5 transition-all duration-500"
                >
                  {/* Image */}
                  <div className={`relative aspect-square ${product.color} flex items-center justify-center overflow-hidden`}>
                    <div className="w-20 h-20 rounded-full bg-white/50 flex items-center justify-center">
                      <ShoppingBag size={32} className="text-aura-text/20" />
                    </div>

                    {product.tag && (
                      <span className="absolute top-4 left-4 bg-aura-text text-white text-xs font-bold px-3 py-1.5 rounded-full">
                        {product.tag}
                      </span>
                    )}

                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => toggleWishlist(product.id)}
                      className={`absolute top-4 right-4 w-9 h-9 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center transition-colors shadow-sm ${
                        wishlist.includes(product.id)
                          ? 'text-red-500'
                          : 'text-aura-text-light hover:text-red-500'
                      }`}
                    >
                      <Heart size={16} className={wishlist.includes(product.id) ? 'fill-red-500' : ''} />
                    </motion.button>

                    {/* Quick Add */}
                    <motion.div
                      initial={{ opacity: 0 }}
                      whileHover={{ opacity: 1 }}
                      className="absolute inset-0 bg-aura-text/5 flex items-center justify-center"
                    >
                      <button className="px-6 py-3 bg-aura-gold text-white text-sm font-medium rounded-full shadow-lg hover:bg-aura-earth transition-colors">
                        Add to Cart
                      </button>
                    </motion.div>
                  </div>

                  {/* Info */}
                  <div className="p-5">
                    <div className="flex items-center gap-1 mb-2">
                      <Star size={12} className="text-aura-gold fill-aura-gold" />
                      <span className="text-xs font-medium text-aura-text">{product.rating}</span>
                      <span className="text-xs text-aura-text-muted">({product.reviews})</span>
                    </div>
                    <h3 className="text-base font-medium text-aura-text mb-2 group-hover:text-aura-gold transition-colors">
                      {product.name}
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-serif text-aura-gold">{formatPrice(product.price)}</span>
                      {product.originalPrice && (
                        <span className="text-sm text-aura-text-muted line-through">
                          {formatPrice(product.originalPrice)}
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Empty State */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <ShoppingBag size={48} className="text-aura-border mx-auto mb-4" />
            <p className="text-aura-text-light">No products found in this category.</p>
          </div>
        )}
      </div>
    </div>
  )
}
