import React from 'react'
import { motion } from 'framer-motion'
import { Heart, Sun, Moon, Sparkles, Check, ArrowRight } from 'lucide-react'
import { ScrollReveal } from '@/components/ui/ScrollReveal'
import { Button } from '@/components/ui/Button'
import { Link } from 'react-router-dom'

const pillars = [
  {
    title: 'Physical Wellness',
    subtitle: 'Honoring the Body',
    desc: 'Our physical programs are designed to restore vitality and strength. From restorative yoga to invigorating movement practices, we guide you to a state of physical harmony.',
    features: ['Yoga & Pilates', 'Nutritional Guidance', 'Detox Programs', 'Personal Training', 'Massage Therapy'],
    color: 'bg-aura-sage',
    textColor: 'text-aura-sage-dark',
    lightColor: 'bg-aura-sage/10',
    icon: Heart,
    price: 'From $89/session',
  },
  {
    title: 'Mental Wellness',
    subtitle: 'Cultivating the Mind',
    desc: 'In a world of constant noise, we offer silence. Our mental wellness practices focus on mindfulness, cognitive clarity, and emotional resilience to help you navigate life with grace.',
    features: ['Meditation Sessions', 'Mindfulness Coaching', 'Sleep Therapy', 'Stress Management', 'Cognitive Training'],
    color: 'bg-aura-earth',
    textColor: 'text-aura-earth',
    lightColor: 'bg-aura-earth/10',
    icon: Sun,
    price: 'From $75/session',
  },
  {
    title: 'Spiritual Wellness',
    subtitle: 'Nourishing the Soul',
    desc: 'Connect with your deeper purpose. Our spiritual offerings provide the space and guidance for introspection, energy work, and the cultivation of inner peace.',
    features: ['Energy Healing', 'Sound Baths', 'Spiritual Retreats', 'Tarot & Astrology', 'Chakra Balancing'],
    color: 'bg-aura-gold',
    textColor: 'text-aura-gold-dark',
    lightColor: 'bg-aura-gold/10',
    icon: Moon,
    price: 'From $120/session',
  },
]

export function WellnessPage() {
  return (
    <div className="pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <ScrollReveal className="text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-aura-gold/10 rounded-full text-aura-gold text-sm font-medium mb-6">
            <Sparkles size={14} />
            <span>Our Programs</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif text-aura-text mb-6 leading-tight">
            The Three Pillars
          </h1>
          <p className="text-aura-text-light text-lg max-w-2xl mx-auto leading-relaxed">
            True wellness is a triad. We address every dimension of your existence to create a complete, lasting transformation.
          </p>
        </ScrollReveal>

        {/* Pillars */}
        <div className="space-y-24">
          {pillars.map((pillar, idx) => (
            <ScrollReveal key={pillar.title}>
              <motion.div
                whileHover={{ scale: 1.005 }}
                transition={{ duration: 0.3 }}
                className={`grid lg:grid-cols-2 gap-12 items-center p-8 md:p-12 lg:p-16 rounded-[2.5rem] ${
                  idx % 2 === 0 ? 'bg-white' : 'bg-aura-beige'
                } border border-aura-border shadow-sm`}
              >
                <div className={idx % 2 !== 0 ? 'lg:order-2' : ''}>
                  <div className={`inline-block px-4 py-1.5 ${pillar.lightColor} rounded-full text-sm font-semibold mb-4 ${pillar.textColor}`}>
                    {pillar.subtitle}
                  </div>
                  <h2 className="text-3xl md:text-4xl font-serif text-aura-text mb-6">{pillar.title}</h2>
                  <p className="text-aura-text-light text-lg leading-relaxed mb-8">
                    {pillar.desc}
                  </p>
                  <ul className="space-y-4 mb-10">
                    {pillar.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-center gap-3 text-aura-text">
                        <div className={`w-6 h-6 rounded-full ${pillar.color} flex items-center justify-center text-white flex-shrink-0`}>
                          <Check size={14} />
                        </div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap items-center gap-4">
                    <Link to="/contact">
                      <Button variant="primary" showArrow>
                        Book a Session
                      </Button>
                    </Link>
                    <span className="text-aura-text-light text-sm">{pillar.price}</span>
                  </div>
                </div>
                <div className={`relative aspect-[4/3] rounded-2xl overflow-hidden ${pillar.lightColor} flex items-center justify-center ${idx % 2 !== 0 ? 'lg:order-1' : ''}`}>
                  <motion.div
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                    className="text-center"
                  >
                    <pillar.icon size={80} className={`${pillar.textColor} opacity-40 mx-auto mb-4`} />
                    <p className={`font-serif text-2xl ${pillar.textColor} opacity-60`}>{pillar.title}</p>
                  </motion.div>
                </div>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>

        {/* Bottom CTA */}
        <ScrollReveal className="mt-24 text-center">
          <div className="bg-aura-text rounded-[2.5rem] p-12 md:p-16 text-white">
            <h2 className="text-3xl md:text-4xl font-serif mb-4">Not Sure Where to Start?</h2>
            <p className="text-white/70 max-w-xl mx-auto mb-8 leading-relaxed">
              Take our complimentary wellness assessment and receive a personalized roadmap tailored to your unique needs and goals.
            </p>
            <Link to="/contact">
              <Button variant="gold" size="lg" showArrow>
                Take the Assessment
              </Button>
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </div>
  )
}
