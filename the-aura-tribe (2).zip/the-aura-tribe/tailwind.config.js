/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        aura: {
          beige: '#F5F1EB',
          ivory: '#FAF9F6',
          sage: '#8A9A87',
          'sage-dark': '#5E6E5B',
          'sage-light': '#A8B8A5',
          earth: '#A68A64',
          'earth-light': '#C4A882',
          gold: '#C5A059',
          'gold-light': '#DCC698',
          'gold-dark': '#A6853F',
          text: '#2C2C2C',
          'text-light': '#6B6B6B',
          'text-muted': '#9A9A9A',
          border: '#E8E6E1',
          'border-light': '#F0EDE8',
        }
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'float-slow': 'float 8s ease-in-out infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'shimmer': 'shimmer 2s linear infinite',
        'spin-slow': 'spin 12s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
      },
    },
  },
  plugins: [],
}
